import { useState } from "react";
import { NavLink, useLocation } from "react-router-dom";
import '../../index.css'
import {
  Cpu,
  HardDrive,
  MemoryStick,
  Network,
  ChevronLeft,
  ChevronRight,
  Terminal,
  Layers,
} from "lucide-react";
const navItems = [
  {
    title: "CPU Scheduling",
    path: "/cpu-scheduling",
    icon: Cpu,
    description: "FCFS, SJF, SRTF, Round Robin",
  },
  {
    title: "Page Replacement",
    path: "/page-replacement",
    icon: MemoryStick,
    description: "FIFO, LRU, Optimal",
  },
  {
    title: "Disk Scheduling",
    path: "/disk-scheduling",
    icon: HardDrive,
    description: "FCFS, SSTF, SCAN, C-SCAN",
  },
  {
    title: "Deadlock Detection",
    path: "/deadlock",
    icon: Network,
    description: "Banker's Algorithm",
  },
  {
    title: "Memory Allocation",
    path: "/memory-allocation",
    icon: Layers,
    description: "First Fit, Best Fit, Worst Fit",
  },
];

export function Sidebar() {
  const [collapsed, setCollapsed] = useState(false);
  const location = useLocation();

  return (
    <div
      className={`h-screen  bg-sidebar border-r border-sidebar-border flex flex-col transition-all duration-300 ${
        collapsed ? "w-20" : "w-72"
      }`}
    >
      {/* Header */}
      <div className="p-4 border-b border-sidebar-border">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-primary/20 flex items-center justify-center glow-primary">
            <Terminal className="w-5 h-5  " />
          </div>

          {!collapsed && (
            <div className="animate-fade-up">
              <h1 className="font-semibold text-foreground text-sm">
                OS Simulator
              </h1>
              <p className="text-xs text-muted-foreground">Advanced</p>
            </div>
          )}
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
        {navItems.map((item) => {
          const isActive = location.pathname === item.path;
          const Icon = item.icon;

          return (
            <NavLink
              key={item.path}
              to={item.path}
              className={`flex items-center gap-3 px-3 py-3 rounded-lg transition-all duration-200 group
                ${
                  isActive
                    ? "bg-primary/15 text-primary"
                    : "text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
                }
              `}
            >
              <Icon
                className={`w-5 h-5 flex-shrink-0 transition-transform duration-200
                  ${isActive ? "animate-pulse-glow" : ""}
                  ${!collapsed ? "group-hover:scale-110" : ""}
                `}
              />

              {!collapsed && (
                <div className="animate-slide-in overflow-hidden">
                  <p className="font-medium text-sm truncate">{item.title}</p>
                  <p className="text-xs text-muted-foreground truncate">
                    {item.description}
                  </p>
                </div>
              )}
            </NavLink>
          );
        })}
      </nav>

      {/* Collapse Button */}
      <div className="p-3 border-t border-sidebar-border">
        <button
          onClick={() => setCollapsed(!collapsed)}
          className="w-full flex items-center justify-center gap-2 px-3 py-2 rounded-lg text-muted-foreground hover:text-foreground hover:bg-sidebar-accent transition-colors"
        >
          {collapsed ? (
            <ChevronRight className="w-5 h-5" />
          ) : (
            <>
              <ChevronLeft className="w-5 h-5" />
              <span className="text-sm">Collapse</span>
            </>
          )}
        </button>
      </div>
    </div>
  );
}
