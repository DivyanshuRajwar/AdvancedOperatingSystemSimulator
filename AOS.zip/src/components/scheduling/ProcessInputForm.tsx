import { useState } from 'react';
import { Plus, Trash2, Play } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Process, SchedulingAlgorithm, AlgorithmOption } from '@/types/scheduling';

const algorithms: AlgorithmOption[] = [
  { value: 'fcfs', label: 'FCFS', description: 'First Come First Serve' },
  { value: 'sjf', label: 'SJF', description: 'Shortest Job First (Non-Preemptive)' },
  { value: 'srtf', label: 'SRTF', description: 'Shortest Remaining Time First (Preemptive)' },
  { value: 'round-robin', label: 'Round Robin', description: 'Time Quantum Based' },
];

interface ProcessInputFormProps {
  onSubmit: (processes: Process[], algorithm: SchedulingAlgorithm, quantum?: number) => void;
}

export function ProcessInputForm({ onSubmit }: ProcessInputFormProps) {
  const [algorithm, setAlgorithm] = useState<SchedulingAlgorithm>('fcfs');
  const [quantum, setQuantum] = useState<number>(2);
  const [processes, setProcesses] = useState<Array<{ arrivalTime: string; burstTime: string }>>([
    { arrivalTime: '0', burstTime: '4' },
    { arrivalTime: '1', burstTime: '3' },
    { arrivalTime: '2', burstTime: '1' },
  ]);

  const addProcess = () => {
    setProcesses([...processes, { arrivalTime: '', burstTime: '' }]);
  };

  const removeProcess = (index: number) => {
    if (processes.length > 1) {
      setProcesses(processes.filter((_, i) => i !== index));
    }
  };

  const updateProcess = (index: number, field: 'arrivalTime' | 'burstTime', value: string) => {
    const updated = [...processes];
    updated[index][field] = value;
    setProcesses(updated);
  };

  const handleSubmit = () => {
    const validProcesses: Process[] = processes
      .filter(p => p.arrivalTime !== '' && p.burstTime !== '')
      .map((p, index) => ({
        id: index + 1,
        arrivalTime: parseInt(p.arrivalTime) || 0,
        burstTime: parseInt(p.burstTime) || 1,
      }));

    if (validProcesses.length > 0) {
      onSubmit(validProcesses, algorithm, algorithm === 'round-robin' ? quantum : undefined);
    }
  };

  return (
    <div className="glass-panel p-6 space-y-6 animate-fade-up">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold text-foreground">Process Configuration</h2>
        <span className="text-xs text-muted-foreground font-mono">
          {processes.length} process{processes.length !== 1 ? 'es' : ''}
        </span>
      </div>

      {/* Algorithm Selection */}
      <div className="space-y-2">
        <Label htmlFor="algorithm" className="text-sm text-muted-foreground">
          Scheduling Algorithm
        </Label>
        <Select value={algorithm} onValueChange={(v) => setAlgorithm(v as SchedulingAlgorithm)}>
          <SelectTrigger className="bg-input border-border">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {algorithms.map((algo) => (
              <SelectItem key={algo.value} value={algo.value}>
                <div className="flex flex-col">
                  <span className="font-medium">{algo.label}</span>
                  <span className="text-xs text-muted-foreground">{algo.description}</span>
                </div>
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Time Quantum for Round Robin */}
      {algorithm === 'round-robin' && (
        <div className="space-y-2 animate-fade-up">
          <Label htmlFor="quantum" className="text-sm text-muted-foreground">
            Time Quantum
          </Label>
          <Input
            id="quantum"
            type="number"
            min="1"
            value={quantum}
            onChange={(e) => setQuantum(parseInt(e.target.value) || 1)}
            className="bg-input border-border font-mono w-32"
          />
        </div>
      )}

      {/* Process Inputs */}
      <div className="space-y-3">
        <div className="grid grid-cols-[auto_1fr_1fr_auto] gap-3 items-center text-xs text-muted-foreground font-medium uppercase tracking-wider">
          <span className="w-12">P#</span>
          <span>Arrival Time</span>
          <span>Burst Time</span>
          <span className="w-10"></span>
        </div>

        {processes.map((process, index) => (
          <div
            key={index}
            className="grid grid-cols-[auto_1fr_1fr_auto] gap-3 items-center animate-slide-in"
            style={{ animationDelay: `${index * 50}ms` }}
          >
            <span className="w-12 h-10 flex items-center justify-center rounded-md bg-muted text-sm font-mono text-primary">
              P{index + 1}
            </span>
            <Input
              type="number"
              min="0"
              placeholder="0"
              value={process.arrivalTime}
              onChange={(e) => updateProcess(index, 'arrivalTime', e.target.value)}
              className="bg-input border-border font-mono"
            />
            <Input
              type="number"
              min="1"
              placeholder="1"
              value={process.burstTime}
              onChange={(e) => updateProcess(index, 'burstTime', e.target.value)}
              className="bg-input border-border font-mono"
            />
            <Button
              variant="ghost"
              size="icon"
              onClick={() => removeProcess(index)}
              disabled={processes.length === 1}
              className="w-10 h-10 text-muted-foreground hover:text-destructive"
            >
              <Trash2 className="w-4 h-4" />
            </Button>
          </div>
        ))}
      </div>

      {/* Action Buttons */}
      <div className="flex gap-3 pt-2">
        <Button
          variant="outline"
          onClick={addProcess}
          className="flex-1 border-border hover:bg-muted"
        >
          <Plus className="w-4 h-4 mr-2" />
          Add Process
        </Button>
        <Button
          onClick={handleSubmit}
          className="flex-1 bg-primary text-primary-foreground hover:bg-primary/90 glow-primary"
        >
          <Play className="w-4 h-4 mr-2" />
          Run Simulation
        </Button>
      </div>
    </div>
  );
}
