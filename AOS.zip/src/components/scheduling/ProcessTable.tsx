import { cn } from '@/lib/utils';

const processColors = [
  'bg-process-1',
  'bg-process-2',
  'bg-process-3',
  'bg-process-4',
  'bg-process-5',
  'bg-process-6',
  'bg-process-7',
  'bg-process-8',
];

export function ProcessTable({ processes, title, showResults = false }) {
  return (
    <div className="glass-panel overflow-hidden animate-fade-up">
      <div className="px-6 py-4 border-b border-border/50">
        <h3 className="font-semibold text-foreground">{title}</h3>
      </div>

      <div className="overflow-x-auto">
        <table className="data-table">
          <thead>
            <tr>
              <th>Process</th>
              <th>Arrival Time</th>
              <th>Burst Time</th>
              {showResults && (
                <>
                  <th>Completion Time</th>
                  <th>Turnaround Time</th>
                  <th>Waiting Time</th>
                </>
              )}
            </tr>
          </thead>

          <tbody>
            {processes.map((process, index) => (
              <tr
                key={process.id}
                className="animate-slide-in"
                style={{ animationDelay: `${index * 50}ms` }}
              >
                <td>
                  <div className="flex items-center gap-2">
                    <span
                      className={cn(
                        'w-3 h-3 rounded-full',
                        processColors[(process.id - 1) % processColors.length]
                      )}
                    />
                    <span className="font-medium">P{process.id}</span>
                  </div>
                </td>

                <td>{process.arrivalTime}</td>
                <td>{process.burstTime}</td>

                {showResults && (
                  <>
                    <td className="text-primary font-medium">
                      {process.completionTime}
                    </td>
                    <td className="text-accent font-medium">
                      {process.turnaroundTime}
                    </td>
                    <td className="text-warning font-medium">
                      {process.waitingTime}
                    </td>
                  </>
                )}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
