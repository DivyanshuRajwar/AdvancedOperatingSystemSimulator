import React from "react";
import { Cpu } from "lucide-react";
function CPUScheduling() {
  return (
    <div className="min-h-screen p-6 lg:p-8">
      {/* Header */}
      <div className="mb-8 animate-fade-up">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-12 h-12 rounded-xl bg-primary/20 flex items-center justify-center glow-primary">
            <Cpu className="w-6 h-6 text-primary" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-foreground">
              CPU Scheduling Algorithms
            </h1>
            <p className="text-muted-foreground">
              Simulate and visualize different CPU scheduling strategies
            </p>
          </div>
        </div>
      </div>
      <div>
        {/* Input Panel */}
        <div className="glass-panel max-w-xl mx-auto p-6 rounded-2xl space-y-6">
          {/* Header */}
          <div className="flex justify-between items-center">
            <h2 className="text-lg font-semibold text-foreground">
              Process Configuration
            </h2>
            <span className="text-sm text-muted-foreground">3 processes</span>
          </div>

          {/* Scheduling Algorithm */}
          <div className="space-y-2">
            <label className="text-sm text-muted-foreground">
              Scheduling Algorithm
            </label>

            <select className="w-full bg-secondary/40 border border-border/50 rounded-xl px-4 py-3 text-foreground focus:outline-none">
              <option>FCFS</option>
              <option>SJF</option>
              <option>Priority</option>
              <option>Round Robin</option>
            </select>

            <p className="text-xs text-muted-foreground">
              First Come First Serve
            </p>
          </div>

          {/* Table Header */}
          <div className="grid grid-cols-[60px_1fr_1fr_40px] gap-3 text-xs text-muted-foreground uppercase tracking-wide">
            <span>P#</span>
            <span>Arrival Time</span>
            <span>Burst Time</span>
            <span></span>
          </div>

          {/* Process Rows */}
          {[1, 2, 3].map((p) => (
            <div
              key={p}
              className="grid grid-cols-[60px_1fr_1fr_40px] gap-3 items-center"
            >
              <div className="bg-secondary/40 rounded-lg px-3 py-2 text-primary font-medium text-center">
                P{p}
              </div>

              <input
                type="number"
                className="bg-secondary/40 rounded-lg px-3 py-2 focus:outline-none text-foreground"
                placeholder="0"
              />

              <input
                type="number"
                className="bg-secondary/40 rounded-lg px-3 py-2 focus:outline-none text-foreground"
                placeholder="0"
              />

              <button className="text-muted-foreground hover:text-destructive">
                🗑️
              </button>
            </div>
          ))}

          {/* Buttons */}
          <div className="flex gap-4 pt-4">
            <button className="flex-1 flex items-center justify-center gap-2 border border-border/50 rounded-xl py-3 text-foreground hover:bg-secondary/40 transition">
              ➕ Add Process
            </button>

            <button className="flex-1 flex items-center justify-center gap-2 bg-primary text-primary-foreground rounded-xl py-3 font-medium hover:opacity-90 transition">
              ▶ Run Simulation
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default CPUScheduling;
