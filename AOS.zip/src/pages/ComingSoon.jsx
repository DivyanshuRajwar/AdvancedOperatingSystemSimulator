import React from 'react'

function ComingSoon() {
  return (
    <div>ComingSoon</div>
  )
}

export default ComingSoon