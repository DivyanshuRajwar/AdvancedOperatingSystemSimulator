import React from 'react'
import {
  Cpu,
  HardDrive,
  MemoryStick,
  Network,
  ChevronLeft,
  ChevronRight,
  Terminal,
  Layers,
} from "lucide-react";
function Index() {
  return (
    <div>Index</div>
  )
}

export default Index