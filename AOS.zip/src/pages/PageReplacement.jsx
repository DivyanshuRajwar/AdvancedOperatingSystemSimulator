import React from 'react'

function PageReplacement() {
  return (
    <div>PageReplacement</div>
  )
}

export default PageReplacement